module.exports = {
  tokens: "8328623468:AAHe6J6c8A63uyq60zuBBJV4DZqWq4SIJak",  // Masukin Bot token kamu
  owners: "1533342840", // Masukin ID Telegram kamu
  port: "20005", // Masukin Port panel kamu 
  ipvps: "http://no-ddos.rofiksolution.my.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/